class WelcomeController < ApplicationController
  def index
  	 @name="Andres es un"
  end
end
