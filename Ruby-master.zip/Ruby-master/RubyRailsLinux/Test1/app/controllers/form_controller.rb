class FormController < ApplicationController
  def form
  end
end
