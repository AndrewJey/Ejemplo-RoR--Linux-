class WelcomeController < ApplicationController
  def index
  	@nombre="Pumba-sama ero-sannin"
  end
end
