class HolaMundo
  def initialize()
  end
  def saluda()
    puts "Hola Mundo" #Puts funciona para imprir algo en la consola.
  end
end
objeto= HolaMundo.new(); #Se utiliza para crear una instancia de objeto.
objeto.saluda #Se llama el metodo saludar que hace un put(imprimir)
gets()