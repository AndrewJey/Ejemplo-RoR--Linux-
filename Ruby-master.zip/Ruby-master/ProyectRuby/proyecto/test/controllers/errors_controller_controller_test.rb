require 'test_helper'

class ErrorsControllerControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
