require 'test_helper'

class AccountControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
