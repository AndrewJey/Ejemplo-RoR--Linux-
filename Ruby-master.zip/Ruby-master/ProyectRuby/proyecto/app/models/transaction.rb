class Transaction < ActiveRecord::Base
end
